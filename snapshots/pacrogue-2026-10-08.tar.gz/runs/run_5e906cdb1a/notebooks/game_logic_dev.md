# Kenji (game_logic_dev) notebook

## Where things live (DOM-free, web/src/logic/)
- `rng.js` mulberry32 `createRng(seed)`: next/int/pick/shuffle/fork; `toSeed`.
- `maze.js` parseTemplate; TILE {FLOOR0, WALL1, DOOR2, CRACKED3}; isWall (incl. cracked), isOpen, neighbours, floodFillPlayer, allPelletsReachable.
- `player.js` stepPlayer (SUB=16, 2/step, turn buffer). `ghosts.js` targeting, mode scheduler, BOSS_KIND.
- `dash_core.js` exports only DASH_DEFAULTS, createDashState, startDash, tickDash, refillDash, isSafe. Defaults (assumed): 2 charges, 24 dash steps, 18 safe steps, 600 recharge, 300 kill points.
- `game.js` createGame({template, seed, config, abilities, behaviours}); owns `state.dash` and `api.isDashing` (state.dash.active > 0). `game.maze` is a private copy. Header comment documents events and step order. Exports normalizeConfig, FRIGHTENED_STEPS, PELLET_POINTS (base values).
- `levels/`: classic1/2 data; `families.js` BASE_CONFIG {ghostCount, ghostSpeedFactor, boss, bossHp 5, frightenedSteps 360, pelletPoints 10, crackedRatio}, FAMILY_CONFIG (speed/cracked/rush/swarm/boss; Dark was removed), addPowerPellets(rows,rng), crackWalls; `generate.js` generateLevel({seed,family}) applies addPowerPellets for rush and rejects results without 8 power pellets.
- `run.js` createRun({seed}): pick(slot|id), levelCleared, playerDied, levelConfig(); `held` is a Map in pick order. generateOffers returns 2 or 0 offers on pick 5.
- `abilities/`: registry.js (offer data, FAMILIES, suitedFor, OFFER_IDS equals POOL_IDS), index.js (BEHAVIOURS, normalizeAbilities), dash.js (DASH_LEVELS data only), wall_burst.js (onWallHit only), ghost_blast.js, chain_reaction.js, combos.js (burst_blast).
- `flow.js` (Rin's, but reads my state): dashInfo(dash), cooldownInfo(abilities, dash), chipsWithCooldowns(held, abilities, dash).

## Conventions
- Hooks `hook(api, state, ...args)` in pick order: onLevelGen, onInput, onWallHit, onGhostKilled, onStep. Combos run after abilities. Logic only emits events.
- Cooldown n: next use exactly n steps later; ability_ready fires at the end of step T+n-1.
- Ghost kills go through killGhostInto. Dash kill: ghost_eaten cause 'dash', flat killPoints. Frightened eat: cause 'eat'. Boss loses 1 HP on first touch per dash (state.dash.bossHit); touches in the safe window do nothing.
- Dash events: dash_start, dash_end, dash_charge (cause 'recharge' or 'power').
- Rush: quadrants split at width/2 and height/2; power pellets prefer tiles >=6 from the quadrant's other power pellets. RUSH_FRIGHTENED_STEPS and RUSH_PELLET_POINTS exported from families.js.
- Wall Burst never breaks the border or the ghost-house ring. A dash with no heading does not start.
- Tests: `tests/<module>.test.js` per logic module. `tests/constraints.test.js` enforces purity (no render imports, window/document/Math.random, colour literals outside palette.js; every logic module needs a test). game.test.js asserts the exact import list of game.js.

## Commands
- `bun test` from /work: last run 703 pass, 0 fail, 26 files. Single file: `bun test tests/run.test.js`.
- Bash denies sed, rm and anything touching /tmp. Use python3 heredoc for multi-line edits and a bun script with unlinkSync to delete files. No git in /work.

## Gotchas
- Test ghosts: set mode = game.state.mode, or a mode change reverses them. Ghosts on Pac-Man's path need house='out'. Set `pac.phased = true` to survive.
- The last pellet clears the level and freezes step(); add a spare pellet in a sealed pen.
- Boss index is after the normal ghosts; use `state.boss`.
- Early returns in step (death, boss kill) skip onStep.
- Tests that loop on run.status must clamp the pick slot to the number of offers, or they never finish. Pick slot 3 with 2 offers returns [] and the status stays 'picking'.

## Unfinished / fragile
- Not covered: browser play, pip drawing, render code.
- T4 (Rin) must remove the render side of Dark: draw.js darkSpans/isLit/drawDark, view.lightRadius in flow.js, the DARK label in screens.js, the darkSpans/isLit tests in fx.test.js, and the dark case in screens.test.js. Check it is done. Pick screens must cope with 2 offers. Rush needs a label and visible power pellets (R6.9).
- R12.4: pips from dashInfo(state.dash); SPACE DASH hint always shown; speed lines and hit-stop from ghost_eaten cause 'dash'.
- Default dash numbers are assumptions; confirm against the spec if one exists.
- Magnet exists only as offerOnly data (partner of ghost_blast and chain_reaction). It has no behaviour. The 'phase' action is ignored.
- Events from killGhost/hitBoss called outside step() are not forwarded to the renderer.
- dashInfo and the dash argument in flow.js are I11 additions; Arlo was notified.
