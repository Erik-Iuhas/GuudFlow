# Planner notebook (Arlo)

## Role/limits
- Planner owns no code. Output is the task list via `guudflow_submit_result` (max 8 cards, sizes S/M, owner_role game_logic_dev (Sol) | canvas_renderer_dev (Lena); reviewer is Bram).
- Planner bash allows only ls, cat, head, tail, wc, grep, cd, git status/diff/log/show/branch. `bun test`, `rg` and pipes are denied. Use Read/Grep tools.
- /work has no git. No server, no screenshots.
- Check `guudflow_read_board` and `/work/docs/decisions.md` (overseer budget/priority rulings) before re-planning. Do not duplicate finished work.

## Code layout (verified on disk at end of the last session)
- Logic is DOM-free, in `web/src/logic/`:
  - `game.js` (932 lines): createGame, step({dir, actions:Set}), events, ghosts, scoring, boss HP.
  - `ghosts.js`, `maze.js` (TILE {FLOOR, WALL, DOOR}, floodFillReachable), `player.js`, `rng.js` (mulberry32).
  - `run.js`: LEVEL_COUNT=5, OFFER_COUNT=3, MAX_ABILITY_LEVEL=2, OFFER_REASONS, generateOffers(rng, family, held), createRun({seed}).
  - `abilities/`: registry.js (FAMILIES speed/cracked/dark/swarm/boss, HOOK_NAMES onStep/onInput/onGhostKilled/onWallHit/onLevelGen, ABILITIES, POOL_IDS, OFFER_IDS, suitedFor, comboPartners), index.js (BEHAVIOURS, normalizeAbilities, createAbility), dash.js, wall_burst.js, ghost_blast.js, chain_reaction.js, combos.js (burst_blast).
  - `levels/`: classic1.js, classic2.js, families.js (FAMILY_CONFIG, crackWalls, wallSegments), generate.js (generateLevel({seed, family}), TEMPLATES, MAX_ATTEMPTS=32).
- Render, in `web/src/render/`: draw.js (drawFrame), flow.js (DOM-free: createView, consumeEvents, stepWhilePlaying, createSession, pickSlot, stepSession, endFrame, cooldownInfo, chipsWithCooldowns, pop and freeze constants), screens.js (pick, summary and win screens, cards), feel.js, fx.js, input.js, layout.js, palette.js.
- Entry: `web/src/main.js` (119 lines).
- Tests: `/work/tests/*.test.js`, one per module: run, registry, abilities_*, combos, constraints, flow, screens, feel, fx, draw, palette, main (source-text checks), game_*.
- `web/index.html` is the page.

## Conventions
- Copy R#.# acceptance lines word for word onto the implementing card.
- Binding decisions D1-D6 and rules 2-9 are in the project spec: determinism with seeded rng, events, hooks as data, palette-only colours, purity.
- Browser event handling lives in the DOM-free `render/flow.js` so bun can test it.
- Offers: slot 1 is the next family's suited ability, slot 2 a level-up or combo partner, slot 3 seeded random. Fall back to the random pool when a slot is unfilled.
- Renderer cards hand visual proof (screenshots) to the reviewer. This is an overseer ruling, so no canvas card is blocked on a screenshot.
- Cards that touch game.js, main.js or draw.js are sequential per owner.

## Status
- My 8-card plan is likely mostly landed: run.js, registry, abilities (dash, wall_burst, ghost_blast, chain_reaction, combos), generate, families, flow, screens, feel and fx all exist with tests. I did not verify behaviour or test pass counts.
- Next planning: read the board and recent commits, run through the spec's R# checks against the files, and plan only gaps.

## Fragile or unfinished (unverified)
- Magnet is offer-only (no behaviour); it is not in POOL_IDS.
- Only one combo exists (burst_blast).
- The R7.9 palette test may fail on render files that use colours outside the palette.
- The reviewer earlier noted that the HUD text and door bar lack tests, and that the canvas clips on small windows.
- main.test.js checks source text, so it breaks on main.js refactors.
- Mode scheduler: game.js owns createModeScheduler. Earlier main.js duplicated it. Check that the duplicate is gone.
- Dash (24 steps) and Blast cooldowns are in steps at 60 Hz (Dash 240/120, Blast 480/300, Wall Burst 240). Keep new cooldowns in the same units.
