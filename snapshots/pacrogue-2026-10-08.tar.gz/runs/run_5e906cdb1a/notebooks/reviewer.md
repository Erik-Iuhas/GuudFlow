# Reviewer (Bram) notebook

## Role
Review only; never edit files. Submit once via `guudflow_submit_result` with `task_id`, verdict, and one `items` entry per acceptance line PLUS one per binding rule (rule-2/3/5/6/9). The `item` text must match the line's full text exactly, or the submit is rejected as "missing a verdict". If a card item and a rule share a leading id (e.g. rule-5), submit both entries with their own full text.

## Commands that work
- `bun test` from /work (~5 s). Last result: 741 pass, 0 fail, 27 files.
- Read/Glob tools work. In some sessions bash `grep`/`wc` and the Grep tool failed (ripgrep error). Fall back to Read with offset/limit.
- /work is not a git repo (`git status` fails). `guudflow_changes` with `task_id` gives the diff, but the output is truncated; read files directly.
- Screenshots: `.guudflow/review/<TASK>/current.png` (read with Read).

## Code map (web/src)
- main.js: the only file reading the clock (performance.now, Date.now). Run seed is Date.now()>>>0.
- logic/: game.js (createGame, step, killGhost, hitBoss, config, abilities, combos), ghosts.js, maze.js (TILE: FLOOR 0, WALL 1, DOOR 2, CRACKED 3), player.js (SUB=16), rng.js (mulberry32), run.js (createRun, generateOffers, 5 levels, events run_won/run_over), dash_core.js (shared dash logic, has its own test dash_core.test.js)
- logic/abilities/: registry.js (offer data; magnet is offer-only), index.js (hook glue), dash.js, wall_burst.js, ghost_blast.js (fireBlast/withinSub), chain_reaction.js, combos.js (burst_blast)
- logic/levels/: classic1.js, classic2.js (pure data), families.js (modifiers), generate.js (generateLevel, retries from derived seeds)
- render/: draw.js, flow.js (session phases picking/playing/frozen/cleared/summary/won), screens.js (pick cards, HUD, summary), fx.js (rings, shards, crumble, trail), feel.js (hit-stop, invert, shake, speed lines, pops), input.js (dirs, Space dash, E blast, 1-3 pick, R restart, M motion), layout.js, palette.js (5 colours)
- tests/ (27 files): constraints.test.js (R7.9 palette scan, rule-8 logic purity, no WebGL or packages, every logic module needs tests/<name>.test.js; abilities/<n>.js maps to abilities_<n>.test.js). Others: flow, render_run, screens, main, input, levels, game_families, game_ghosts, etc.

## Binding rules checked each card
rule-2 (fixed 60 Hz, integer positions, seeded RNG only), rule-3 (ability data and hooks, events only), rule-5 (4 G tiles, extra ghosts rotate, boss at house centre), rule-6 (step({dir, actions:Set}), no key codes in logic), rule-9 (templates + modifiers + connectivity retry).

## Review history (all passed)
T1 run/registry/constraints; T2 death freeze/pops/banner; T3 cracked/classic2/generator/boss; T6 run-flow UI; T4 Dash/Wall Burst/Blast; T5 Chain/combo/extra ghost; T7 ability render; T8 feel pass.

## Gotchas
- tests/draw.test.js is root-owned, so the renderer dev puts draw tests in tests/fx.test.js and feel.test.js. Acceptable.
- Staged screenshot pages get deleted. Only the pre-check screenshot is available, so most visual states are verified by mock-canvas tests plus one image.
- No reference images exist; visual diffs are by eye.
- I never opened a real browser; timing and feel are judged from tests and code.

## Fragile / unfinished (non-blocking notes raised)
- Cracked walls are loud (dense pink); tune later.
- Wall Burst L2 never breaks ghost-house walls (8-neighbour ring); beyond spec, documented.
- Dash never kills ghosts, so cause 'dash' is never emitted.
- Combo fires at the step the dash ends, not at the first broken wall.
- Each wall broken during a dash triggers its own hit-stop and pop; long dashes may stutter.
- A game-ending step returns before onStep.
- The extra ghost from Blast/Chain applies once however many are held (cap 16).
- Swarm screenshot did not clearly show 6+ ghosts (covered by draw tests).
- Boss level refills pellets on the last pellet (pellets_reset), plus boss points (500 per hit, 2000 for the kill): additions beyond spec.
