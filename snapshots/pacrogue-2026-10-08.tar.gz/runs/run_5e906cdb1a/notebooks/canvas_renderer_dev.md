# Notebook: canvas_renderer_dev (Rin/Lena), pacrogue

## Where things live (web/src/)
- `main.js`: entry; only reader of `Date.now`/`performance.now`/`matchMedia`. `buildLevel(cfg)` = `generateLevel` + `createGame({template, config, seed, abilities: cfg.held})`. Frame loop: spend hit-stop steps without `game.step`, else `stepSession(session, consumeInput, 1, feel)`, then `drawFrame(ctx, state, {...session.view, feel: feel.view()})`, `endFrame`, `feel.update()`.
- `render/flow.js`: pure view fns (`createView`, `consumeEvents`, `advanceFrame`, `popLook`, `cooldownInfo(abilities)` = ghost_blast only, `chipsWithCooldowns(held, abilities)`, `dashInfo(dash)` used by draw.js) and mutable session (`createSession`, `pickSlot`, `stepSession`, `endFrame`, `canRestart`). Phases: picking|playing|frozen|cleared|summary|won. Imports feel.js (`INVERT_FRAMES = INVERTED_MAX_FRAMES`). Dash-kill pops get CYAN outline.
- `render/feel.js`: `createFeel()` (`onEvents`, `hitStop`, `tickHitStop`, `update`, `view`, `toggleReducedMotion`, `reset`). Exports `INVERTED_MAX_FRAMES = 2`, `eventImpact`, `popFor`, `shakeOffset`, `speedLineRects`. Hit-stop counts logic steps; the rest counts render frames. Dash kill shake 6. Flash cap: max 2 consecutive inverted frames; forced flashes (combo/death/boss kill) wait one plain frame; non-forced ones inside the cap are dropped.
- `render/fx.js`: pure effect list (ring, burst, crumble, trail).
- `render/draw.js`: `drawFrame`. Order: HUD, speed lines (corridors only), walls (ink body rect per tile, then cracked rects), pellets, fx, pops, Pac-Man, ghosts last. Boss drawn 2x (`ghostScale`, `bossPips`). `drawHud` calls `drawDashPips(ctx, dashInfo(state.dash))` outside the `view.hud` guard. Dark render and HUD "DEAD" text are deleted. Only logic import allowed: `SUB` (tests enforce).
- `render/screens.js`: pick cards (`pickLayout` hint built from offer slots; footer follows card count), chips (`chipLayout`), dash pips (`pipLayout`, `drawDashPips`; constants PIPS_X=316, PIPS_Y=26, PIP_W=16, PIP_H=24, PIP_GAP=4), `keyHints(held)` (always starts 'SPACE DASH'), `drawHudRun`, panels, motion indicator. No logic imports (test scans).
- `render/input.js`: Space='dash', E='blast', 1/2/3 pick, R restart, M motion. Only `consumeInput()` ({dir, actions}) reaches `game.step`.
- `render/palette.js`: the only colour literals. `layout.js`: 480x576 logical grid, integer scale.
- tests: feel/fx/screens/render_run/flow/input/draw/main .test.js. `render_run.test.js` = 5-level session on real generator, 3 seeds.

## Conventions
- Flat `fillRect` with palette colours; Pac-Man pie is the only arc. No alpha/gradient/strokeText (outlines = 8 offset copies).
- Draw from `game.maze` (Wall Burst mutates tiles). Pops drawn on the raw ctx (not inverted).
- Score pops in `view.pops`; name pops in `feel.pops`. Inversion: INK<->WHITE, PINK<->CYAN, YELLOW->INK.
- Dash HUD: pips in top strip (filled YELLOW, empty frame CYAN, recharge bar PINK, label WHITE while `dashInfo.safe`). Dash chip has no countdown; Blast chip keeps cooldown bar.
- Reduced motion: no shake/flash/speed lines; hit-stop and pops stay. Not persisted.

## Commands
- `bun test` (all; ~4 s). Single: `bun test tests/feel.test.js`.
- Visual: temporary `web/_preview.html` + `guudflow_screenshot file=web/_preview.html`; delete afterwards. Pop colours are only asserted with reduced motion on (flash colours apply only on the inverted ctx).

## Gotchas
- Bash mostly denied (allowed: git, ls, cat, grep, bun test, python3, node). Edit with edit/write tools; `write` outside /work is denied.
- Root-owned test files: edit in place with the edit tool; if that fails, replace via temp file + `os.replace`. Remove helper scripts afterwards.
- Test mock ctxs need `translate`/`transform`/`rect`/`clip`. `drawPops` guards `ctx.transform`.
- Footer holds only 4 chips plus the hint; a 5th chip wraps below the canvas. The ability pool has 4 pickable ones.
- 5-level test forces a clear by wrapping `game.step` (sets `state.cleared`, adds `level_cleared`); no pellets eaten.
- Pop clamp assumes monospace advance 0.6 em.

## Unfinished / fragile
- Not tested in a live browser; pixel look under inversion and pips under an inverted flash are unchecked.
- Pip layout is hard-coded for 480 logical width. Boss pips on row 1 overlap the HUD divider (cosmetic).
- Cracked tiles are still dense pink (loud); untuned.
- Boss level can't be cleared in browser until an ability or a frightened eat hits the boss.
- Events from `killGhost`/`hitBoss` called outside `step()` never reach flow/feel.
- Magnet is data-only. Chain Reaction emits `chain_kill` (drawn).
- Doc debts for Arlo: I11/C12 (feel.js exports INVERTED_MAX_FRAMES, flow.js imports feel.js, cooldownInfo(abilities), dashInfo export); Rush logic constants from T2 undeclared in C8.
