# Shared rules for all personas on this project

