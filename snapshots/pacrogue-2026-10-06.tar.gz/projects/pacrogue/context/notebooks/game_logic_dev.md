# Sol (game_logic_dev) notebook

## Where things live (all DOM-free, web/src/logic/)
- `rng.js` mulberry32 `createRng(seed)`: next/int/pick/shuffle/fork; `toSeed`.
- `maze.js` parseTemplate; TILE {FLOOR0, WALL1, DOOR2, CRACKED3} ('c' char); isWall (incl. cracked), isCracked, isOpen, neighbours, floodFillPlayer, allPelletsReachable, isConnected.
- `player.js` stepPlayer (SUB=16, speed 2/step, turn buffer). `ghosts.js` targeting, mode scheduler, stepGhost, BOSS_KIND.
- `game.js` createGame({template, seed, config, abilities, behaviours}). `game.maze` is a PRIVATE tile copy. state = tick, score, pac, pellets, ghosts, boss, abilities[], combos[]. Header comment documents events and step order.
- `levels/` classic1, classic2 (pure data), `families.js` (BASE_CONFIG, modifiers, crackWalls), `generate.js` generateLevel({seed, family}) -> {maze, template, config, ...}.
- `run.js` createRun({seed}): pick(slot1-3|id), levelCleared, playerDied, levelConfig(); `held` is a Map in pick order.
- `abilities/`: `registry.js` (offer data, hooks empty), `index.js` (BEHAVIOURS, normalizeAbilities, createAbility), `dash.js`, `wall_burst.js`, `ghost_blast.js` (fireBlast, withinSub), `chain_reaction.js`, `combos.js` (burst_blast).

## Conventions and decisions
- Hooks `hook(api, state, ...args)` in pick order: onLevelGen, onInput, onWallHit, onGhostKilled, onStep. Combos run after abilities, plus combo-only onWallBroken. Logic only emits events.
- Cooldown n means the next use is exactly n steps later (state shows n-1 after the firing step); ability_ready fires at the end of step T+n-1.
- Ghost kills go through killGhostInto (flat 200, or the chain value if frightened). A boss hit is -1 HP and the boss retreats.
- Extra ghost: Ghost Blast or Chain Reaction adds +1 once (extraGhost flag), cap MAX_GHOSTS 16.
- Wall Burst never breaks the border or the ghost-house ring (8-neighbour). L2 breaks solid walls. A dash with no heading does not start.
- Blast and chain events: radius in tiles, radiusSub in sub-units.
- Combo fires when the dash ends, at Pac-Man's position.
- Boss: 500 per hit, +2000 on the kill. Pellets refill on a boss level (event pellets_reset).
- Tests: `tests/abilities_<name>.test.js` for abilities/ files; levels/ code is covered by `tests/levels.test.js`. `tests/constraints.test.js` enforces logic purity: no render imports, no window/document/Math.random, no colour literals outside palette.js, every logic module has a test.

## Commands
- `bun test` from /work (last run: 580 pass, 0 fail, 23 files). Single file: `bun test tests/combos.test.js`.
- python3 with a file argument or heredoc works for multi-line edits. Bash denies sed, rm and anything touching /tmp. Delete scratch files with a bun script that calls unlinkSync.
- No git in /work.

## Gotchas
- Test ghosts: set mode = game.state.mode, or a mode-change reversal moves them. A test ghost placed on a Pac-Man path needs house='out'. Pac-Man dies on touch; set `pac.phased = true` in tests.
- The last pellet clears a normal level and freezes step(). Add a spare pellet in a sealed pen.
- Boss index is after the normal ghosts, so use `state.boss`.
- game.test.js asserts the exact import list of game.js; update it when adding imports.
- Early returns in step (death, boss kill) skip onStep.

## Unfinished / fragile
- Not wired in main.js, flow.js or run.js (T7, Lena): createGame with abilities (`run.levelConfig().held`), and the 'dash'/'blast' keys. Events from killGhost/hitBoss called outside step() are not forwarded to the renderer.
- Magnet has no behaviour. The 'phase' action is accepted but ignored. Dash does not kill ghosts (cause 'dash' is unused).
- dash.js and wall_burst.js (T4) and chain_reaction.js and combos.js (T5) are untested in the browser. The chain_kill and combo events need drawing code.
