# Planner notebook (Arlo)

## Role/limits
- Planner owns no code; output is the task list via `guudflow_submit_result` (max 8 cards, sizes S/M only, owner_role in game_logic_dev | canvas_renderer_dev).
- Bash in the planner sandbox allows only: ls, cat, head, tail, wc, grep, cd, git status/diff/log/show/branch. `bun test`, `rg` and pipes through other tools are denied. Use the Read and Grep tools, and `grep -n` via bash for exports.
- No git in /work. Cannot run a server or screenshot.

## Code layout (repo at commit 5d964ef plus later runs)
- Logic (DOM-free): `web/src/logic/` has `game.js` (createGame, step(input), events, killGhost, ghosts, chain scoring; header comment documents state and events), `ghosts.js` (targeting, mode scheduler, stepGhost, speeds), `maze.js` (parseTemplate, TILE {FLOOR, WALL, DOOR}, floodFillReachable, isConnected), `player.js`, `rng.js` (mulberry32), and `levels/classic1.js`.
- Render: `web/src/render/` has `draw.js` (drawFrame, ghostStyle, endMessage), `input.js`, `layout.js`, `palette.js`.
- Entry: `web/src/main.js` (rAF accumulator, 60 Hz).
- Tests: `tests/*.test.js`. main.test.js checks source text. game_ghosts.test.js covers R2.1-2.5.

## Findings
- Ghosts, eating, collision, player_died and ghost_eaten {x,y,points,chain,cause} already exist in game.js. Old T7/T8/T12 were therefore mostly done. T13 (constraint tests) was not done.
- game.step already accepts {dir, actions:Set}. Actions are parsed and ignored. Unknown action names throw.
- main.js duplicates createModeScheduler, which game.js owns. T2 deletes the duplicate.
- main.js has no reaction to player_died or level_cleared. Any key restarts.
- TILE has no CRACKED type. There is only one template (classic1). No run.js, no abilities/, no generator.

## Plan submitted this session (8 cards)
- Sol: T1 run.js + registry + offers + constraints tests (B4). T3 cracked tile, second template, generate.js, families, extra ghosts and boss in game (B6). T4 ability hooks + Dash, Wall Burst, Blast (B5). T5 Chain Reaction, combo, +1 ghost, L2 stacking (B5).
- Lena: T2 death freeze/flash, ghost-eat pops, clear banner (B3). T6 run-flow UI (B4). T7 render abilities and families (B5). T8 feel pass (B10).
- Dependencies: T4 needs T1 and T3. T5 needs T4. T6 needs T1, T2 and T3. T7 needs T4, T5 and T6. T8 needs T7.
- Chains: Sol T1/T3, then T4, T5. Lena T2, T6, T7, T8. All of these touch game.js or main.js/draw.js, so they are sequential.

## Conventions
- Copy R#.# acceptance lines word for word onto the implementing card.
- Binding decisions D1-D6 and rules 2-9 (determinism, events, hooks as data, palette-only colours, rule-8 purity) are in the project spec.
- Event handling for the browser should live in a DOM-free `render/flow.js` so bun can test it.
- Offers: slot 1 is the next family's suited ability, slot 2 a level-up or combo partner, slot 3 seeded random. Fall back to the random pool when a slot is unfilled.

## Fragile or unfinished
- All 8 cards were still unstarted at plan time, and I did not check whether they completed.
- T1 is the largest card (run + registry + offers + constraints). T4 may spill; the planned split is Dash and Wall Burst first, then Blast.
- Magnet is offer-only (no behaviour). It is not in the core pool of 4.
- The R7.9 palette test may fail on existing render files. T1 is told to make a minimal fix by importing from the palette.
- The reviewer previously noted that the HUD text and the door bar lack tests, and that the canvas clips on small windows.
- Check `guudflow_read_board` and the last commits before re-planning. Do not duplicate finished cards.
