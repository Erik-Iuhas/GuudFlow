# Reviewer (Bram) notebook

## Role
Review only; never edit files. Submit once via `guudflow_submit_result` with `task_id`, verdict, and one `items` entry per acceptance line PLUS one per binding rule (rule-2/3/5/6/9). The `item` text must match the line's full text exactly, or the submit is rejected as "missing a verdict". If a card's item and a rule share a leading id (e.g. rule-5), submit both entries with their own full text.

## Commands that work
- `bun test` from /work (about 3.5 s). Last result: 661 pass, 0 fail, 25 files.
- Read/Glob tools work. In some sessions bash `grep`/`wc` and the Grep tool were blocked or failed (ripgrep error). Fall back to Read with offset/limit.
- No git repo in /work (`git status` fails). `guudflow_changes` with `task_id` gives the diff, but the output is truncated; read files directly.
- Screenshots: `.guudflow/review/<TASK>/current.png` (read with the Read tool).

## Code map (web/src)
- logic/: game.js (createGame, step, killGhost, hitBoss, config, abilities, combos), ghosts.js, maze.js (TILE: FLOOR 0, WALL 1, DOOR 2, CRACKED 3), player.js (SUB=16), rng.js (mulberry32), run.js (createRun, generateOffers, 5 levels, events run_won/run_over)
- logic/abilities/: registry.js (offer data; magnet is offer-only), index.js (hook glue), dash.js, wall_burst.js, ghost_blast.js (fireBlast/withinSub), chain_reaction.js, combos.js (burst_blast)
- logic/levels/: classic1.js, classic2.js (pure data), families.js (modifiers), generate.js (generateLevel with retry from derived seeds)
- render/: draw.js, flow.js (session, phases picking/playing/frozen/cleared/summary/won), screens.js (pick cards, HUD, summary), fx.js (rings, shards, crumble, trail), feel.js (hit-stop, invert, shake, speed lines, pops), input.js (dirs, Space dash, E blast, 1-3 pick, R restart, M motion), layout.js, palette.js (5 colours)
- main.js: the only file reading the clock (performance.now, Date.now); the run seed is Date.now()>>>0.
- tests/: constraints.test.js (R7.9 palette scan, rule-8 logic purity, no WebGL or packages, each logic module needs tests/<name>.test.js; abilities/<n>.js maps to abilities_<n>.test.js).

## Binding rules checked each card
rule-2 (fixed 60 Hz, integer positions, seeded RNG only), rule-3 (ability data and hooks, events only), rule-5 (4 G tiles, extra ghosts rotate, boss at house centre), rule-6 (step({dir, actions:Set}), no key codes in logic), rule-9 (templates + modifiers + connectivity retry).

## Review history (all passed)
T1 run/registry/constraints; T2 death freeze/pops/banner; T3 cracked/classic2/generator/boss; T6 run-flow UI; T4 Dash/Wall Burst/Blast; T5 Chain/combo/extra ghost; T7 ability render; T8 feel pass.

## Gotchas
- tests/draw.test.js is root-owned, so the renderer dev puts draw tests in tests/fx.test.js and feel.test.js. This is acceptable.
- Staged screenshot pages get deleted. Only the pre-check screenshot is available, so many visual states are verified by mock-canvas tests plus one image.
- No reference images exist, so visual diffs are by eye.

## Fragile / unfinished (non-blocking notes raised)
- The cracked walls are loud (dense pink); tune later.
- Wall Burst L2 never breaks ghost-house walls (an 8-neighbour ring), which goes beyond the spec and is documented.
- The Dash ability never kills ghosts, so cause 'dash' is never emitted.
- The combo fires at the step the dash ends, not at the first broken wall.
- Each wall broken during a dash triggers its own hit-stop and pop, so long dashes may stutter.
- A game-ending step returns before onStep.
- The extra ghost from Blast/Chain applies once however many are held (cap 16).
- The Swarm screenshot panel did not clearly show 6+ ghosts (covered by draw tests).
- main.js had a duplicated-comment typo, fixed in T7.
- Boss level refills pellets on the last pellet (pellets_reset), plus boss points (500 per hit, 2000 for the kill): additions beyond the spec.
- I did not open a real browser in any review; timing and feel are judged from tests and code.
